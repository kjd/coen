#!/bin/sh
#
# $Id: autogen.sh 62 2010-02-10 10:31:07Z jakob $

autoreconf --install --force
