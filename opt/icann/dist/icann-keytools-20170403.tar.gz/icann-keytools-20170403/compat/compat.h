/* $Id: compat.h 299 2010-05-27 07:23:20Z jakob $ */

#ifndef _COMPAT_H_
#define _COMPAT_H_

#ifndef HAVE_STRLCPY
#include "strlcpy.h"
#endif

#ifndef HAVE_STRLCAT
#include "strlcat.h"
#endif

#endif /* _COMPAT_H_ */
